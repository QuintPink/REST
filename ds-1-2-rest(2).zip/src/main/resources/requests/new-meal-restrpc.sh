curl -X POST localhost:8080/restrpc/meals -H 'Content-type:application/json' -d @new-meal.json -v

